package org.example;

public class Stundent {
} import java.util.ArrayList;
  import java.util.List;
  public class Student{
      private int studentId;
      private String firstName;
      private String lastName;
       public  Student(int studentId, String firstName, String lastName){

       }   this.studentId = studentId;
        this.firstName = firstName;
        this.lastName = lastName;
      public int getStudentId() {
          return studentId;
      }

      public String getFirstName() {
          return firstName;
      }

      public String getLastName() {
          return lastName;

      } public class StudentsGroup {
          private Student captain;
          private List<Student> studentsList;
          private List<String> assignments;

          public StudentsGroup(Student captain) {
              this.captain = captain;
              this.studentsList = new ArrayList<>();
              this.assignments = new ArrayList<>();
          }

          public Student getCaptain() {
              return captain;
          }

          public List<Student> getStudentsList() {
              return new ArrayList<>(studentsList);
          }

          public List<String> getAssignments() {
              return new ArrayList<>(assignments);
          }

          public void changeCaptain(Student newCaptain) {
              if (studentsList.contains(newCaptain)) {
                  captain = newCaptain;
              }
          }

          public void addStudent(Student student) {
              studentsList.add(student);
          }

          public void removeStudent(Student student) {
              if (studentsList.contains(student) && !student.equals(captain)) {
                  studentsList.remove(student);
              }
          }

          public void addAssignment(String assignment) {
              assignments.add(assignment);
          }

          public void markAssignmentDone(Student student, String assignment) {
              if (studentsList.contains(student) && assignments.contains(assignment)) {
                  // Add your implementation here to mark the assignment as done for the specific student.
              }
          }
      }
      public class Main {
          public static void main(String[] args) {
              Student student1 = new Student(1, "Іван", "Петров");
              Student student2 = new Student(2, "Марія", "Сидорова");

              StudentsGroup group = new StudentsGroup(student1);
              group.addStudent(student2);

              System.out.println("Староста групи: " + group.getCaptain().getFirstName() + " " + group.getCaptain().getLastName());
              System.out.println("Список студентів:");
              for (Student student : group.getStudentsList()) {
                  System.out.println(student.getFirstName() + " " + student.getLastName());
              }

              group.addAssignment("Вивчити інкапсуляцію");
              group.addAssignment("Зробити домашнє завдання");

              // Позначимо завдання як виконане для студента student1
              group.markAssignmentDone(student1, "Вивчити інкапсуляцію");
          }
      }
      public class Main {
          public static void main(String[] args) {
              Student student1 = new Student(1, "Іван", "Петров");
              Student student2 = new Student(2, "Марія", "Сидорова");

              StudentsGroup group = new StudentsGroup(student1);
              group.addStudent(student2);

              System.out.println("Староста групи: " + group.getCaptain().getFirstName() + " " + group.getCaptain().getLastName());
              System.out.println("Список студентів:");
              for (Student student : group.getStudentsList()) {
                  System.out.println(student.getFirstName() + " " + student.getLastName());
              }

              group.addAssignment("Вивчити інкапсуляцію");
              group.addAssignment("Зробити домашнє завдання");

              // Позначимо завдання як виконане для студента student1
              group.markAssignmentDone(student1, "Вивчити інкапсуляцію");
          }
      }

